package com.example.googleblackwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.SearchManager
import android.widget.RemoteViews

class GoogleSearchWidget : AppWidgetProvider() {
    override fun onUpdate(
        context: Context,
        manager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        appWidgetIds.forEach { id -> updateWidget(context, manager, id) }
    }

    companion object {
        fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_google_search)

            val searchIntent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra(SearchManager.QUERY, "")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val searchPending = PendingIntent.getActivity(
                context, 100 + widgetId, searchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.search_area, searchPending)
            views.setOnClickPendingIntent(R.id.google_logo, searchPending)

            val voiceIntent = Intent(context, VoiceSearchActivity::class.java)
            val voicePending = PendingIntent.getActivity(
                context, 200 + widgetId, voiceIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.microphone, voicePending)

            val lensIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://lens.google.com/"))
            lensIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val lensPending = PendingIntent.getActivity(
                context, 300 + widgetId, lensIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.lens, lensPending)

            manager.updateAppWidget(widgetId, views)
        }
    }
}
