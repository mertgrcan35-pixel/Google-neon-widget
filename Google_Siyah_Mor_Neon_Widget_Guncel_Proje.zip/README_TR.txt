GOOGLE SIYAH WIDGET - Xiaomi Mi 10T Pro

Bu proje Android ana ekranına eklenebilen gerçek bir App Widget örneğidir.
- Arama alanına dokununca Android'in web arama uygulamasını açar (cihazda Google varsa genellikle Google).
- Mikrofon simgesi Android ses tanıma ekranını açar; tanınan ifade Google aramasında açılır.

APK oluşturma:
1. Bilgisayara Android Studio kurun.
2. Bu klasörü Android Studio ile Open olarak açın.
3. Gradle senkronizasyonunu tamamlayın.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.
5. Oluşan APK'yı telefona aktarın ve kurun.

Telefona ekleme:
1. Uygulamayı kurun.
2. Ana ekranda boş alana uzun basın.
3. Widget'lar > Google Siyah Widget bölümünü bulun.
4. Widget'ı ana ekrana sürükleyin.

Not:
- İlk açılışta internet bağlantısı gerekir.
- Sesli arama için cihazda Google uygulaması veya uyumlu bir konuşma tanıma hizmeti bulunmalıdır.
- Xiaomi/MIUI sürümüne göre widget listesinde görünmesi için uygulamayı kurduktan sonra ana ekranı yenilemek veya telefonu yeniden başlatmak gerekebilir.


IPHONE ILE BULUTTA APK OLUSTURMA (BILGISAYARSIZ)
1. iPhone Safari'den https://github.com adresine girip ücretsiz hesap açın/giriş yapın.
2. Sağ üstte + > New repository ile GoogleBlackWidget adında Public veya Private repo oluşturun.
3. Bu ZIP'i iPhone Dosyalar uygulamasında açıp içindeki proje dosyalarını çıkarın.
4. GitHub reposunda Add file > Upload files ile proje klasörünün içindeki tüm dosya ve klasörleri yükleyin.
   .github klasörünün de yüklendiğinden emin olun. Dosya yükleme ekranı klasörleri kabul etmezse
   GitHub'ın web arayüzünden dosyaları tek tek/klasör bazında ekleyin.
5. Commit changes deyin. Actions sekmesine girin; Build Android APK iş akışı çalışacaktır.
6. İşlem tamamlanınca iş akışını açın, Artifacts bölümündeki Google-Siyah-Widget-APK dosyasını indirin.
7. ZIP içindeki app-debug.apk dosyasını Xiaomi'ye aktarın ve kurun.

NOT: GitHub arayüzü iPhone'da değişebilir. Repo yüklemesi sırasında sorun yaşarsanız ekran
görüntüsü gönderin; bulunduğunuz adıma göre yönlendirebilirim.

GUNCEL TASARIM: Gece mavisi-mor arka plan, keskin/az yuvarlatilmis koseler ve mavi-mor gradient G logosu.


    TASARIM GUNCELLEMESI:
    Widget, kullanicinin gonderdigi mavi-mor neon cam, keskin koseli tasarima gore duzenlendi.
    Arama alani web aramasini acar, mikrofon Android konusma tanimayi baslatir,
    Lens simgesi Google Lens web sayfasini acar. G logosu su an mor tonlu metin tabanli
    bir G'dir; istenirse sonraki surumde daha yakin ozel logo cizimi eklenebilir.
    Arka plan duvar kagidi widget'a gomulu degildir; ana ekranda ayri kullanilabilir.
    